<?php
/**
 * tpAdmin [a web admin based ThinkPHP5]
 *
 * @author yuan1994 <tianpian0805@gmail.com>
 * @link http://tpadmin.yuan1994.com/
 * @copyright 2016 yuan1994 all rights reserved.
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */

return [
    // 七牛云存储配置信息
    "accessKey" => "bKuXyGUf1qrgqwyfvcWlLTh2ublMhWlIwVUXFHND",
    "secretKey" => "79_qLvHCfTIqOywmUuri-diSV0P_KVXvCN4tgmJ8",
    "bucket"    => "rybbaby", // 存储空间
    "domain"    => "http://7j1y9l.com1.z0.glb.clouddn.com/", // 访问域名
];