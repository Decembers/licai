<?php

return array (
  'module' => 'admin',
  'menu' =>
  array (
    0 => 'add',
    1 => 'forbid',
    2 => 'resume',
    3 => 'delete',
    4 => 'recyclebin',
    5 => 'saveorder',
  ),
  'create_config' => true,
  'controller' => 'Commodity',
  'title' => '',
  'form' =>
  array (
    2 =>
    array (
      'title' => '商品名称',
      'name' => 'name',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写商品名称',
        'errormsg' => '',
      ),
    ),
    3 =>
    array (
      'title' => '商品图片',
      'name' => 'image',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写商品图片',
        'errormsg' => '',
      ),
    ),
    4 =>
    array (
      'title' => '商品单价',
      'name' => 'price',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写商品单价',
        'errormsg' => '',
      ),
    ),
    5 =>
    array (
      'title' => '养殖周期',
      'name' => 'rate',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写养殖周期',
        'errormsg' => '',
      ),
    ),
    7 =>
    array (
      'title' => '商品详情',
      'name' => 'content',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写商品详情',
        'errormsg' => '',
      ),
    ),
    9 =>
    array (
      'title' => '商品数量',
      'name' => 'number',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'require' => '1',
      'validate' =>
      array (
        'datatype' => '*',
        'nullmsg' => '请填写商品数量',
        'errormsg' => '',
      ),
    ),
  ),
  'model' => '1',
  'auto_timestamp' => '1',
  'validate' => '1',
);
