<?php

return array (
  'module' => 'admin',
  'menu' => 
  array (
    0 => 'forbid',
    1 => 'resume',
    2 => 'delete',
    3 => 'recyclebin',
  ),
  'create_config' => true,
  'controller' => 'Order',
  'title' => '',
  'form' => 
  array (
    2 => 
    array (
      'title' => '订单编号',
      'name' => 'number',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    5 => 
    array (
      'title' => '订单金额',
      'name' => 'order_price',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    6 => 
    array (
      'title' => '商品单价',
      'name' => 'sp_price',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
    7 => 
    array (
      'title' => '商品数量',
      'name' => 'sp_count',
      'type' => 'text',
      'option' => '',
      'default' => '',
      'search_type' => 'text',
      'validate' => 
      array (
        'datatype' => '',
        'nullmsg' => '',
        'errormsg' => '',
      ),
    ),
  ),
  'model' => '1',
  'auto_timestamp' => '1',
);
